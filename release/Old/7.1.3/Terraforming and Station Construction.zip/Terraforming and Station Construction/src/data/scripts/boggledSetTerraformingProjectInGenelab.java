package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.*;
import com.fs.starfarer.api.impl.campaign.econ.CommRelayCondition;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarEvent;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventCreator;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventWithPerson;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.rulecmd.AddRemoveCommodity;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.loading.Description;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.campaign.*;
import com.fs.starfarer.combat.entities.terrain.Planet;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidBeltTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin;
import com.fs.starfarer.loading.specs.PlanetSpec;
import com.fs.starfarer.rpg.Person;
import data.campaign.econ.industries.*;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.lang.String;

public class boggledSetTerraformingProjectInGenelab extends BaseCommandPlugin
{
    protected SectorEntityToken entity;

    public boggledSetTerraformingProjectInGenelab() {}

    public boggledSetTerraformingProjectInGenelab(SectorEntityToken entity) {
        this.init(entity);
    }

    protected void init(SectorEntityToken entity)
    {
        this.entity = entity;
    }

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap)
    {
        if(dialog == null) return false;

        this.entity = dialog.getInteractionTarget();

        Boggled_Genelab lab = (Boggled_Genelab) this.entity.getMarket().getIndustry("BOGGLED_GENELAB");
        lab.resetDaysWithoutShortageTerraforming();

        // Vanilla and TASC planet type transformations

        if(ruleId.equals("setParadiseTransformation"))
        {
            lab.setTerraformingProjectType("Paradise transformation");
        }
        else if(ruleId.equals("setTerranTransformation"))
        {
            lab.setTerraformingProjectType("Terran transformation");
        }
        else if(ruleId.equals("setWaterTransformation"))
        {
            lab.setTerraformingProjectType("Water transformation");
        }
        else if(ruleId.equals("setJungleTransformation"))
        {
            lab.setTerraformingProjectType("Jungle transformation");
        }
        else if(ruleId.equals("setAridTransformation"))
        {
            lab.setTerraformingProjectType("Arid transformation");
        }
        else if(ruleId.equals("setTundraTransformation"))
        {
            lab.setTerraformingProjectType("Tundra transformation");
        }
        else if(ruleId.equals("setVolcanicTransformation"))
        {
            lab.setTerraformingProjectType("Volcanic transformation");
        }
        else if(ruleId.equals("setFrozenTransformation"))
        {
            lab.setTerraformingProjectType("Frozen transformation");
        }

        // Unknown Skies planet type transformations
        // Could add more types if requested

        else if(ruleId.equals("setAuricTransformation"))
        {
            lab.setTerraformingProjectType("Auric transformation");
        }
        else if(ruleId.equals("setContinentalTransformation"))
        {
            lab.setTerraformingProjectType("Continental transformation");
        }
        else if(ruleId.equals("setArtificialTransformation"))
        {
            lab.setTerraformingProjectType("Artificial transformation");
        }

        // Condition changes

        else if(ruleId.equals("setHabitableConditionChange"))
        {
            lab.setTerraformingProjectType("Make world habitable");
        }
        else if(ruleId.equals("setAtmosphereConditionChange"))
        {
            lab.setTerraformingProjectType("Optimize atmospheric conditions");
        }
        else if(ruleId.equals("setCoreConditionChange"))
        {
            lab.setTerraformingProjectType("Optimize gravity and tectonics");
        }
        else if(ruleId.equals("setMiscConditionChange"))
        {
            lab.setTerraformingProjectType("Remove inimical biosphere, radiation and meteor impacts");
        }
        else if(ruleId.equals("setTransplutonicConditionChange"))
        {
            lab.setTerraformingProjectType("Remove rare ore deposits");
        }
        else if(ruleId.equals("setResourcesConditionChange"))
        {
            lab.setTerraformingProjectType("Maximize all resources");
        }
        else if(ruleId.equals("setUnknownSkiesConditionChange"))
        {
            lab.setTerraformingProjectType("Remove all Unknown Skies conditions");
        }

        return true;
    }
}