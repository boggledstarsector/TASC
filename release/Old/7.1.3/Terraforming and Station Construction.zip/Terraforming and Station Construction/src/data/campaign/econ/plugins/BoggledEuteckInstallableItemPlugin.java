package data.campaign.econ.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseInstallableIndustryItemPlugin;
import com.fs.starfarer.api.impl.campaign.econ.impl.InstallableItemEffect;
import com.fs.starfarer.api.impl.campaign.econ.impl.ItemEffectsRepo;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.HashMap;
import java.util.Map;
import java.lang.String;
import data.campaign.econ.industries.Boggled_Genelab;

public class BoggledEuteckInstallableItemPlugin extends BaseInstallableIndustryItemPlugin
{
    private Boggled_Genelab industry;

    public BoggledEuteckInstallableItemPlugin(Boggled_Genelab industry) {
        this.industry = industry;
    }

    public static Map<String, BoggledEuteckInstallableItemPlugin.EuteckEffect> EUTECK_EFFECTS = new HashMap<String, BoggledEuteckInstallableItemPlugin.EuteckEffect>()
    {
        {
            this.put("boggled_euteck", new BoggledEuteckInstallableItemPlugin.EuteckEffect()
            {
                public void apply(Industry industry) { }

                public void unapply(Industry industry) { }

                public void addItemDescription(TooltipMakerAPI text, SpecialItemData data, InstallableItemDescriptionMode mode)
                {
                    SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec("boggled_euteck");
                    String name = "E.U.T.E.C.K.";
                    String pre = "";
                    float pad = 0.0F;
                    if (mode != InstallableItemDescriptionMode.MANAGE_ITEM_DIALOG_LIST && mode != InstallableItemDescriptionMode.INDUSTRY_TOOLTIP) {
                        if (mode == InstallableItemDescriptionMode.MANAGE_ITEM_DIALOG_INSTALLED || mode == InstallableItemDescriptionMode.INDUSTRY_MENU_TOOLTIP) {
                            pre = name + " currently installed. ";
                        }
                    } else {
                        pre = name + " ";
                    }

                    if (mode == InstallableItemDescriptionMode.INDUSTRY_MENU_TOOLTIP || mode == InstallableItemDescriptionMode.CARGO_TOOLTIP) {
                        pad = 10.0F;
                    }

                    text.addPara(pre + "Permanently terraforms planets.", pad, Misc.getHighlightColor(), new String[]{""});
                }
            });
        }
    };

    public interface EuteckEffect
    {
        void apply(Industry var1);

        void unapply(Industry var1);

        void addItemDescription(TooltipMakerAPI var1, SpecialItemData var2, InstallableItemDescriptionMode var3);
    }

    public void addItemDescription(TooltipMakerAPI text, SpecialItemData data, InstallableItemDescriptionMode mode)
    {
        if(data.getId().equals("boggled_euteck"))
        {
            String name = "E.U.T.E.C.K.";
            String pre = "";
            float pad = 0.0F;
            if (mode != InstallableItemDescriptionMode.MANAGE_ITEM_DIALOG_LIST && mode != InstallableItemDescriptionMode.INDUSTRY_TOOLTIP) {
                if (mode == InstallableItemDescriptionMode.MANAGE_ITEM_DIALOG_INSTALLED || mode == InstallableItemDescriptionMode.INDUSTRY_MENU_TOOLTIP) {
                    pre = name + " currently installed. ";
                }
            } else {
                pre = name + ". ";
            }

            if (mode == InstallableItemDescriptionMode.INDUSTRY_MENU_TOOLTIP || mode == InstallableItemDescriptionMode.CARGO_TOOLTIP) {
                pad = 10.0F;
            }

            text.addPara(pre + "Permanently terraforms planets.", pad, Misc.getHighlightColor(), new String[]{""});
        }
    }

    public String getMenuItemTitle()
    {
        return this.getCurrentlyInstalledItemData() == null ? "Install item..." : "Manage item...";
    }

    public String getUninstallButtonText()
    {
        return "Uninstall item";
    }

    public boolean isInstallableItem(CargoStackAPI stack)
    {
        if (stack.isSpecialStack() && stack.getSpecialItemSpecIfSpecial().getId().equals("boggled_euteck"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public SpecialItemData getCurrentlyInstalledItemData()
    {
        return this.industry.getEuteck();
    }

    public void setCurrentlyInstalledItemData(SpecialItemData data)
    {
        this.industry.setEuteck(data);
    }

    public String getNoItemCurrentlyInstalledText()
    {
        return "No item currently installed";
    }

    public String getNoItemsAvailableText()
    {
        return "No suitable items available";
    }

    public String getNoItemsAvailableTextRemote()
    {
        return "No item available in storage";
    }

    public String getSelectItemToAssignToIndustryText()
    {
        return "Select item to install for " + this.industry.getCurrentName();
    }

    public boolean isMenuItemTooltipExpandable() {
        return false;
    }

    public float getMenuItemTooltipWidth() {
        return super.getMenuItemTooltipWidth();
    }

    public boolean hasMenuItemTooltip() {
        return super.hasMenuItemTooltip();
    }

    public void createMenuItemTooltip(TooltipMakerAPI tooltip, boolean expanded)
    {
        float pad = 3.0F;
        float opad = 10.0F;
        tooltip.addPara("Certain Domain-era artifacts might be installed here to improve the colony. Only one such artifact may be installed at an industry at a time.", 0.0F);
        SpecialItemData data = this.industry.getSpecialItem();
        if (data == null)
        {
            tooltip.addPara(this.getNoItemCurrentlyInstalledText() + ".", opad);
        }
        else
        {
            SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(this.industry.getEuteck().getId());
            TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48.0F);
            BoggledEuteckInstallableItemPlugin.EuteckEffect effect = (BoggledEuteckInstallableItemPlugin.EuteckEffect)BoggledEuteckInstallableItemPlugin.EUTECK_EFFECTS.get(this.industry.getEuteck().getId());
            effect.addItemDescription(text, this.industry.getEuteck(), InstallableIndustryItemPlugin.InstallableItemDescriptionMode.INDUSTRY_TOOLTIP);
            tooltip.addImageWithText(opad);
        }
    }
}
