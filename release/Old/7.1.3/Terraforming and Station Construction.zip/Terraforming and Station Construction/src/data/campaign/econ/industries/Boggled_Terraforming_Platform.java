package data.campaign.econ.industries;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.lang.String;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.*;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.econ.impl.Farming;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.IconRenderMode;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.CoreCampaignPluginImpl;
import com.fs.starfarer.api.impl.campaign.CoreScript;
import com.fs.starfarer.api.impl.campaign.events.CoreEventProbabilityManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposableLuddicPathFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposablePirateFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetRouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.MercFleetManagerV2;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import com.fs.starfarer.campaign.*;
import data.campaign.econ.BoggledStationConstructionIDs;
import data.campaign.econ.boggledTools;
import com.fs.starfarer.api.impl.campaign.econ.CommRelayCondition;

import javax.swing.*;

public class Boggled_Terraforming_Platform extends BaseIndustry
{
    public boolean canBeDisrupted()
    {
        return true;
    }

    private int daysWithoutShortage = 0;
    private int lastDayChecked = 0;
    private int requiredDaysToMakeHab = 200;

    private boolean marketConditionsOkForPlatform()
    {
        if(this.market.hasCondition("no_atmosphere") || this.market.hasCondition("thin_atmosphere") || this.market.hasCondition("dense_atmosphere") || this.market.hasCondition("toxic_atmosphere"))
        {
            return false;
        }
        else if(this.market.hasCondition("habitable") && this.market.hasCondition("mild_climate"))
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public void apply()
    {
        super.apply(true);
    }

    @Override
    public void advance(float amount)
    {
        super.advance(amount);

        if(this.marketConditionsOkForPlatform() && this.isFunctional())
        {
            CampaignClockAPI clock = Global.getSector().getClock();

            if(clock.getDay() != lastDayChecked)
            {
                daysWithoutShortage++;
                lastDayChecked = clock.getDay();

                if(daysWithoutShortage >= requiredDaysToMakeHab)
                {
                    if (this.market.isPlayerOwned())
                    {
                        MessageIntel intel = new MessageIntel("Weather on " + market.getName(), Misc.getBasePlayerColor());
                        intel.addLine("    - Terraformed");
                        intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                        intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                        Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, market);
                    }

                    if(this.market.hasCondition("extreme_weather"))
                    {
                        this.market.removeCondition("extreme_weather");
                    }

                    if(!this.market.hasCondition("habitable"))
                    {
                        this.market.addCondition("habitable");
                    }

                    if(!this.market.hasCondition("mild_climate"))
                    {
                        this.market.addCondition("mild_climate");
                    }

                    boggledTools.surveyAll(market);
                    boggledTools.refreshSupplyAndDemand(market);
                    boggledTools.refreshAquacultureAndFarming(market);
                }
            }
        }
    }

    @Override
    public boolean isAvailableToBuild()
    {
        if(Global.getSettings().getBoolean("boggledTerraformingContentEnabled") && Global.getSettings().getBoolean("boggledTerraformingPlatformEnabled") && this.market.getPlanetEntity() != null && this.market.hasSpaceport() && boggledTools.marketHasOrbitalStation(this.market))
        {
            if(this.marketConditionsOkForPlatform())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    @Override
    public boolean showWhenUnavailable()
    {
        if(Global.getSettings().getBoolean("boggledTerraformingContentEnabled") && Global.getSettings().getBoolean("boggledTerraformingPlatformEnabled") && this.market.getPlanetEntity() != null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public String getUnavailableReason()
    {
        if(Global.getSettings().getBoolean("boggledTerraformingContentEnabled") && Global.getSettings().getBoolean("boggledTerraformingPlatformEnabled"))
        {
            if(this.market.hasCondition("habitable") && this.market.hasCondition("mild_climate"))
            {
                return this.market.getName() + " is already human-habitable and the weather patters are already mild.";
            }
            else if(!this.marketConditionsOkForPlatform())
            {
                return "The atmosphere on " + this.market.getName() + " is absent, too thin, too dense, and/or toxic. It will be necessary to remedy the atmospheric problems first before the air on " + this.market.getName() + " can be made human-breathable.";
            }
            else if(!this.market.hasSpaceport())
            {
                return (this.market.getName() + " lacks a functioning spaceport. It will be impossible to build a terraforming platform in orbit around " + this.market.getName() + " due to logistical problems until a spaceport becomes operational.");
            }
            else if(!boggledTools.marketHasOrbitalStation(this.market))
            {
                return (this.market.getName() + " lacks an orbital station. The terraforming platform must be attached to an existing orbital station that can provide labor, logistics support and security.");
            }
            else
            {
                return "Error in getUnavailableReason() in Terraforming Platform. Please tell Boggled about this on the forums.";
            }
        }
        else
        {
            return "Error in getUnavailableReason() in Terraforming Platform. Please tell Boggled about this on the forums.";
        }
    }

    public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade)
    {
        daysWithoutShortage = 0;
        lastDayChecked = 0;

        super.notifyBeingRemoved(mode, forUpgrade);
    }

    @Override
    protected void addRightAfterDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode)
    {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();

        //Inserts climate status after description
        if(this.marketConditionsOkForPlatform() && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            //200 days; divide daysWithoutShortage by 2 to get the percent
            int percentComplete = daysWithoutShortage / 2;

            //Makes sure the tooltip doesn't say "100% complete" on the last day due to rounding up 99.5 to 100
            if(percentComplete > 99)
            {
                percentComplete = 99;
            }

            tooltip.addPara("Weather modification is approximately %s complete on " + this.market.getName() + ".", opad, highlight, new String[]{percentComplete + "%"});
        }

        // Tell the player they can remove it
        if(!this.marketConditionsOkForPlatform() && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            tooltip.addPara("The weather on " + this.market.getName() + " has been permanently terraformed. The terraforming platform can now be deconstructed without any risk of regression.", opad);
        }

        if(this.isDisrupted() && this.marketConditionsOkForPlatform() && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            Color bad = Misc.getNegativeHighlightColor();

            Pair<String, Integer> deficit = this.getMaxDeficit(new String[]{"domain_artifacts"});
            if(deficit.two != 0)
            {
                tooltip.addPara("Progress is stalled while the terraforming platform is disrupted.", bad, opad);
            }
        }
    }

    @Override
    public float getPatherInterest() { return super.getPatherInterest() + 2.0f; }

    @Override
    public boolean canImprove() { return false; }

    public boolean canInstallAICores() {
        return false;
    }
}

