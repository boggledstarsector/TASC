package data.campaign.econ.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CargoTransferHandlerAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin.InstallableItemDescriptionMode;
import com.fs.starfarer.api.campaign.impl.items.GenericSpecialItemPlugin;
import com.fs.starfarer.api.impl.campaign.econ.impl.*;
//import com.fs.starfarer.api.impl.campaign.econ.impl.NanoforgeInstallableItemPlugin;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;

public class BoggledEuteckSpecialItemPlugin extends GenericSpecialItemPlugin
{
    public BoggledEuteckSpecialItemPlugin() { }

    @Override
    public void createTooltip(TooltipMakerAPI tooltip, boolean expanded, CargoTransferHandlerAPI transferHandler, Object stackSource)
    {
        float pad = 0.0F;
        float opad = 10.0F;
        tooltip.addTitle(this.getName());
        LabelAPI design = Misc.addDesignTypePara(tooltip, this.getDesignType(), opad);
        float bulletWidth = 70.0F;
        if (design != null)
        {
            bulletWidth = design.computeTextWidth("Design type: ");
        }

        Color textColor = Misc.getTextColor();
        Color industryColor = Misc.getBasePlayerColor();
        tooltip.setBulletWidth(bulletWidth);
        tooltip.setBulletColor(Misc.getGrayColor());
        tooltip.setBulletedListMode("Installed in:");
        tooltip.addPara("Genelab", industryColor, opad);
        tooltip.setBulletedListMode((String)null);

        tooltip.addPara(this.spec.getDesc(), textColor, opad);

        this.addCostLabel(tooltip, opad, transferHandler, stackSource);
    }
}
