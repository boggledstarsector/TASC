package data.campaign.econ.industries;

import java.awt.*;
import java.util.*;
import java.lang.String;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.*;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.util.Pair;
import data.campaign.econ.boggledTools;

public class Boggled_Stellar_Reflector_Array extends BaseIndustry
{
    public static float IMPROVE_DEFENSE_BONUS = 1.25f;

    public boolean canBeDisrupted() {
        return true;
    }

    public void advance(float amount)
    {
        super.advance(amount);

        if(!this.market.hasCondition("solar_array") && this.isFunctional())
        {
            Random random = new Random();
            float minDays = 210f;
            float maxDays = 270f;

            float disruptionDur = minDays + random.nextFloat() * (maxDays - minDays);
            this.setDisrupted(disruptionDur, true);
        }
    }

    protected void notifyDisrupted()
    {
        boggledTools.removeCondition(this.market, "solar_array");
    }

    protected void disruptionFinished()
    {
        boggledTools.addCondition(this.market, "solar_array");
    }

    public void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " + "Terraforming progresses %s faster.", 0.0F, highlight, (int) ((1.0F - UPKEEP_MULT) * 100.0F) + "%", "" + DEMAND_REDUCTION, "25%");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " + "Terraforming progresses %s faster.", opad, highlight, (int) ((1.0F - UPKEEP_MULT) * 100.0F) + "%", "" + DEMAND_REDUCTION, "25%");
        }
    }

    @Override
    public boolean canImprove()
    {
        return true;
    }

    protected void applyImproveModifiers()
    {
        if (isImproved())
        {
            this.market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult("boggled_stellar_reflector_array_improve_bonus", IMPROVE_DEFENSE_BONUS, "Improvements (Stellar Reflector Array)");
        }
        else
        {
            this.market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult("boggled_stellar_reflector_array_improve_bonus");
        }
    }

    @Override
    public void addImproveDesc(TooltipMakerAPI info, ImprovementDescriptionMode mode) {
        float opad = 10f;
        Color highlight = Misc.getHighlightColor();

        float a = IMPROVE_DEFENSE_BONUS;
        String str = Strings.X + (a) + "";

        if (mode == ImprovementDescriptionMode.INDUSTRY_TOOLTIP) {
            info.addPara("Ground defenses increased by %s.", 0f, highlight, str);
        } else {
            info.addPara("Increases ground defenses by %s.", 0f, highlight, str);
        }

        info.addSpacer(opad);
        super.addImproveDesc(info, mode);
    }

    @Override
    protected void buildingFinished()
    {
        super.buildingFinished();

        MarketAPI market = this.market;
        boggledTools.addCondition(market, "solar_array");

        if(boggledTools.numReflectorsInOrbit(market) >= 3)
        {
            return;
        }

        boolean mirrorsOrShades = boggledTools.getCreateMirrorsOrShades(market);
        boggledTools.clearReflectorsInOrbit(market);

        //True is mirrors, false is shades
        if(mirrorsOrShades)
        {
            SectorEntityToken orbitFocus = market.getPrimaryEntity().getOrbitFocus();
            float orbitRadius = market.getPrimaryEntity().getRadius() + 80.0F;
            if (orbitFocus != null && orbitFocus.isStar())
            {
                StarSystemAPI system = market.getStarSystem();

                //First mirror
                SectorEntityToken mirrorAlpha = system.addCustomEntity("stellar_mirror_alpha", ("Stellar Mirror Alpha"), "stellar_mirror", market.getFactionId());
                mirrorAlpha.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle() - 30, orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
                mirrorAlpha.setCustomDescriptionId("stellar_mirror");

                //Second mirror
                SectorEntityToken mirrorBeta = system.addCustomEntity("stellar_mirror_beta", ("Stellar Mirror Beta"), "stellar_mirror", market.getFactionId());
                mirrorBeta.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle(), orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
                mirrorBeta.setCustomDescriptionId("stellar_mirror");

                //Third mirror
                SectorEntityToken mirrorGamma = system.addCustomEntity("stellar_mirror_gamma", ("Stellar Mirror Gamma"), "stellar_mirror", market.getFactionId());
                mirrorGamma.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle() + 30, orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
                mirrorGamma.setCustomDescriptionId("stellar_mirror");
            }
            else
            {
                StarSystemAPI system = market.getStarSystem();

                //First mirror
                SectorEntityToken mirrorAlpha = system.addCustomEntity("stellar_mirror_alpha", ("Stellar Mirror Alpha"), "stellar_mirror", market.getFactionId());
                mirrorAlpha.setCircularOrbitPointingDown(market.getPrimaryEntity(), 0, orbitRadius, orbitRadius / 10.0F);
                mirrorAlpha.setCustomDescriptionId("stellar_mirror");

                //Second mirror
                SectorEntityToken mirrorBeta = system.addCustomEntity("stellar_mirror_beta", ("Stellar Mirror Beta"), "stellar_mirror", market.getFactionId());
                mirrorBeta.setCircularOrbitPointingDown(market.getPrimaryEntity(), 120, orbitRadius, orbitRadius / 10.0F);
                mirrorBeta.setCustomDescriptionId("stellar_mirror");

                //Third mirror
                SectorEntityToken mirrorGamma = system.addCustomEntity("stellar_mirror_gamma", ("Stellar Mirror Gamma"), "stellar_mirror", this.market.getFactionId());
                mirrorGamma.setCircularOrbitPointingDown(market.getPrimaryEntity(), 240, orbitRadius, orbitRadius / 10.0F);
                mirrorGamma.setCustomDescriptionId("stellar_mirror");
            }
        }
        else
        {
            SectorEntityToken orbitFocus = market.getPrimaryEntity().getOrbitFocus();
            float orbitRadius = market.getPrimaryEntity().getRadius() + 80.0F;
            if (orbitFocus != null && orbitFocus.isStar())
            {
                StarSystemAPI system = market.getStarSystem();

                //First shade
                SectorEntityToken shadeAlpha = system.addCustomEntity("stellar_shade_alpha", ("Stellar Shade Alpha"), "stellar_shade", market.getFactionId());
                shadeAlpha.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle() + 154, orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
                shadeAlpha.setCustomDescriptionId("stellar_shade");

                //Second shade
                SectorEntityToken shadeBeta = system.addCustomEntity("stellar_shade_beta", ("Stellar Shade Beta"), "stellar_shade", market.getFactionId());
                shadeBeta.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle() + 180, orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
                shadeBeta.setCustomDescriptionId("stellar_shade");

                //Third shade
                SectorEntityToken shadeGamma = system.addCustomEntity("stellar_shade_gamma", ("Stellar Shade Gamma"), "stellar_shade", market.getFactionId());
                shadeGamma.setCircularOrbitPointingDown(market.getPrimaryEntity(), market.getPrimaryEntity().getCircularOrbitAngle() + 206, orbitRadius, market.getPrimaryEntity().getCircularOrbitPeriod());
                shadeGamma.setCustomDescriptionId("stellar_shade");
            }
            else
            {
                StarSystemAPI system = market.getStarSystem();

                //First shade
                SectorEntityToken shadeAlpha = system.addCustomEntity("stellar_shade_alpha", ("Stellar Shade Alpha"), "stellar_shade", market.getFactionId());
                shadeAlpha.setCircularOrbitPointingDown(market.getPrimaryEntity(), 0, orbitRadius, orbitRadius / 10.0F);
                shadeAlpha.setCustomDescriptionId("stellar_shade");

                //Second shade
                SectorEntityToken shadeBeta = system.addCustomEntity("stellar_shade_beta", ("Stellar Shade Beta"), "stellar_shade", market.getFactionId());
                shadeBeta.setCircularOrbitPointingDown(market.getPrimaryEntity(), 120, orbitRadius, orbitRadius / 10.0F);
                shadeBeta.setCustomDescriptionId("stellar_shade");

                //Third shade
                SectorEntityToken shadeGamma = system.addCustomEntity("stellar_shade_gamma", ("Stellar Shade Gamma"), "stellar_shade", market.getFactionId());
                shadeGamma.setCircularOrbitPointingDown(market.getPrimaryEntity(), 240, orbitRadius, orbitRadius / 10.0F);
                shadeGamma.setCustomDescriptionId("stellar_shade");
            }
        }
    }

    public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade)
    {
        super.notifyBeingRemoved(mode, forUpgrade);

        boggledTools.clearReflectorsInOrbit(this.market);
        boggledTools.removeCondition(market, "solar_array");
    }

    @Override
    public String getCurrentImage()
    {
        if(!boggledTools.getCreateMirrorsOrShades(this.market))
        {
            return Global.getSettings().getSpriteName("boggled", "stellar_shade");
        }
        else
        {
            return Global.getSettings().getSpriteName("boggled", "stellar_mirror");
        }
    }

    @Override
    public void apply()
    {
        super.apply(true);

        if(Global.getSettings().getBoolean("boggledDomainTechContentEnabled") && Global.getSettings().getBoolean("boggledDomainArchaeologyEnabled"))
        {
            int size = this.market.getSize();
            this.demand("domain_artifacts", size - 2);
        }

        boolean shortage = false;
        if(Global.getSettings().getBoolean("boggledDomainTechContentEnabled") && Global.getSettings().getBoolean("boggledDomainArchaeologyEnabled"))
        {
            Pair<String, Integer> deficit = this.getMaxDeficit(new String[]{"domain_artifacts"});
            if(deficit.two != 0)
            {
                shortage = true;
            }
        }

        if(shortage)
        {
            getUpkeep().modifyMult("deficit", 3.0f, "Artifacts shortage");
        }
        else
        {
            getUpkeep().unmodifyMult("deficit");
        }
    }

    @Override
    public void unapply()
    {
        super.unapply();
    }

    @Override
    public boolean isAvailableToBuild()
    {
        MarketAPI market = this.market;

        if(!Global.getSettings().getBoolean("boggledTerraformingContentEnabled") || !Global.getSettings().getBoolean("boggledStellarReflectorArrayEnabled"))
        {
            return false;
        }

        //Can't be built by station markets
        if(market.getPrimaryEntity().hasTag("station")) { return false; }

        //Can't be built on volcanic planets
        if(boggledTools.getPlanetType(market.getPlanetEntity()).equals("volcanic"))
        {
            return false;
        }

        //Can't be built on unknown planet types
        if(boggledTools.getPlanetType(market.getPlanetEntity()).equals("unknown"))
        {
            return false;
        }

        //Can't be built on dark planets. All planets in nebulas and orbiting black holes have dark condition.
        if(market.hasCondition("dark")) { return false; }

        //Check if spaceport is built
        if(!market.hasSpaceport())
        {
            return false;
        }

        return true;
    }

    @Override
    public boolean showWhenUnavailable()
    {
        MarketAPI market = this.market;

        if(!Global.getSettings().getBoolean("boggledTerraformingContentEnabled") || !Global.getSettings().getBoolean("boggledStellarReflectorArrayEnabled"))
        {
            return false;
        }

        //Can't be built by station markets
        if(market.getPrimaryEntity().hasTag("station")) { return false; }

        return true;
    }

    @Override
    public String getUnavailableReason()
    {
        MarketAPI market = this.market;

        //Can't be built on volcanic planets
        if(boggledTools.getPlanetType(market.getPlanetEntity()).equals("volcanic"))
        {
            return "Climate conditions on lava planets like " + market.getName() + " are driven by volcanic activity rather than radiation from a star. Reflectors would have no effect here.";
        }

        //Can't be built on unknown planet types
        if(boggledTools.getPlanetType(market.getPlanetEntity()).equals("unknown"))
        {
            return "Planet type unrecognized. Please tell Boggled about this on the forums so he can add support for this planet type. The type is: " + market.getPlanetEntity().getTypeId();
        }

        //Can't be built on dark planets. All planets in nebulas and orbiting black holes have dark condition.
        if(market.hasCondition("dark")) { return "Stellar reflectors won't have any effect on a world that receives no light."; }

        //Check if spaceport is built
        if(!market.hasSpaceport())
        {
            return (market.getName() + " lacks a functioning spaceport. It will be impossible to build a stellar reflector array in orbit around " + market.getName() + " due to logistical problems until a spaceport becomes operational.");
        }

        return "Error in getUnavailableReason() in the Stellar Reflector Array. Please tell Boggled about this on the forums.";
    }

    public float getPatherInterest()
    {
        //Tries to avoid giving Eventide and Eochu Bres pather cells if they wouldn't normally have them
        if(this.market.isPlayerOwned())
        {
            return 10.0F;
        }
        else
        {
            return super.getPatherInterest();
        }
    }

    public boolean canInstallAICores() {
        return false;
    }
}

