package data.campaign.econ.industries;

import java.awt.Color;
import java.util.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.campaign.econ.*;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.impl.campaign.intel.MessageIntel;

import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.util.Pair;
import data.campaign.econ.boggledTools;
import data.campaign.econ.plugins.BoggledEuteckInstallableItemPlugin;

public class Boggled_Genelab extends BaseIndustry {

    protected SpecialItemData euteck = null;

    public static float UPKEEP_MULT = 0.75F;
    public static int DEMAND_REDUCTION = 1;

    //Need to update strings if value changed
    public static float IMPROVE_BONUS = 1.20f;

    private int daysWithoutShortagePollution = 0;
    private int lastDayCheckedPollution = 0;
    private int requiredDaysToRemovePollution = 200;

    private int daysWithoutShortageLobsters = 0;
    private int lastDayCheckedLobsters = 0;
    private int requiredDaysToAddLobsters = 200;

    private int daysWithoutShortageTerraforming = 0;
    private int lastDayCheckedTerraforming = 0;
    private int requiredDaysToCompleteTerraforming = Global.getSettings().getInt("boggledTerraformingTime");

    private String terraformingProjectType = "Paradise transformation";

    public String getTerraformingProjectType()
    {
        return this.terraformingProjectType;
    }

    public void setTerraformingProjectType(String type)
    {
        this.terraformingProjectType = type;
    }

    public void resetDaysWithoutShortageTerraforming()
    {
        this.daysWithoutShortageTerraforming = 0;
    }

    public int getNumDaysRemainingForTerraformingProject()
    {
        return this.requiredDaysToCompleteTerraforming - this.daysWithoutShortageTerraforming;
    }

    public boolean canBeDisrupted() { return true; }

    public boolean genelabHasShortage()
    {
        boolean shortage = false;
        if(Global.getSettings().getBoolean("boggledDomainTechContentEnabled") && Global.getSettings().getBoolean("boggledDomainArchaeologyEnabled"))
        {
            Pair<String, Integer> deficit = this.getMaxDeficit(new String[]{"domain_artifacts"});
            if(deficit.two != 0)
            {
                shortage = true;
            }
        }

        return shortage;
    }

    public void advance(float amount)
    {
        super.advance(amount);

        boolean shortage = genelabHasShortage();

        CampaignClockAPI clock = Global.getSector().getClock();

        //
        // Terraforming
        //

        // boggledTools.sendDebugIntelMessage("Temp sup: " + temperatureProblemsSuppressed() + " Light sup: " + lightingProblemsSuppressed() + " Water: " + hasWater());

        if(this.euteck != null && !this.terraformingProjectType.equals("None"))
        {
            if(staticConditionsMet() && dynamicConditionsMet() && !shortage && this.isFunctional())
            {
                if(clock.getDay() != this.lastDayCheckedTerraforming)
                {
                    this.daysWithoutShortageTerraforming++;
                    this.lastDayCheckedTerraforming = clock.getDay();
                }

                if(daysWithoutShortageTerraforming >= requiredDaysToCompleteTerraforming)
                {
                    doTerraforming();
                    consumeEuteckIfNecessary();
                    this.daysWithoutShortageTerraforming = 0;
                    this.lastDayCheckedTerraforming = 0;
                    this.terraformingProjectType = "None";
                }
            }
        }
        else
        {
            this.daysWithoutShortageTerraforming = 0;
            this.lastDayCheckedTerraforming = 0;
        }

        //
        // Pollution removal
        //

        if(this.market.hasCondition("pollution") && this.isFunctional())
        {
            if(clock.getDay() != this.lastDayCheckedPollution && !shortage)
            {
                this.daysWithoutShortagePollution++;
                this.lastDayCheckedPollution = clock.getDay();

                if(this.market.hasCondition("habitable") && this.market.hasIndustry(Industries.HEAVYINDUSTRY) && this.market.getIndustry(Industries.HEAVYINDUSTRY).getSpecialItem() != null && (this.market.getIndustry(Industries.HEAVYINDUSTRY).getSpecialItem().getId().equals(Items.CORRUPTED_NANOFORGE) || this.market.getIndustry(Industries.HEAVYINDUSTRY).getSpecialItem().getId().equals(Items.PRISTINE_NANOFORGE)))
                {
                    this.daysWithoutShortagePollution = 0;
                    this.lastDayCheckedPollution = clock.getDay();
                }

                if(daysWithoutShortagePollution >= requiredDaysToRemovePollution)
                {
                    if (this.market.isPlayerOwned())
                    {
                        MessageIntel intel = new MessageIntel("Pollution on " + this.market.getName(), Misc.getBasePlayerColor());
                        intel.addLine("    - Remediated");
                        intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                        intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                        Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, this.market);
                    }

                    this.daysWithoutShortagePollution = 0;
                    this.lastDayCheckedPollution = clock.getDay();

                    if(this.market.hasCondition("pollution"))
                    {
                        this.market.removeCondition("pollution");
                    }

                    boggledTools.surveyAll(this.market);
                    boggledTools.refreshSupplyAndDemand(this.market);
                    boggledTools.refreshAquacultureAndFarming(this.market);
                }
            }
        }

        //
        // Lobster seeding
        //

        if(this.market.hasCondition("water_surface") && !this.market.hasCondition("volturnian_lobster_pens") && this.isFunctional())
        {
            if(clock.getDay() != this.lastDayCheckedLobsters && !shortage)
            {
                this.daysWithoutShortageLobsters++;
                this.lastDayCheckedLobsters = clock.getDay();

                if(this.daysWithoutShortageLobsters >= this.requiredDaysToAddLobsters)
                {
                    if (this.market.isPlayerOwned())
                    {
                        MessageIntel intel = new MessageIntel("Lobster seeding on " + this.market.getName(), Misc.getBasePlayerColor());
                        intel.addLine("    - Completed");
                        intel.setIcon(Global.getSector().getPlayerFaction().getCrest());
                        intel.setSound(BaseIntelPlugin.getSoundStandardUpdate());
                        Global.getSector().getCampaignUI().addMessage(intel, CommMessageAPI.MessageClickAction.COLONY_INFO, this.market);
                    }

                    this.daysWithoutShortageLobsters = 0;
                    this.lastDayCheckedLobsters = clock.getDay();

                    boggledTools.addCondition(this.market, "volturnian_lobster_pens");

                    boggledTools.surveyAll(this.market);
                    boggledTools.refreshSupplyAndDemand(this.market);
                    boggledTools.refreshAquacultureAndFarming(this.market);
                }
            }
        }
    }

    @Override
    public void apply()
    {
        super.apply(true);

        if(Global.getSettings().getBoolean("boggledDomainTechContentEnabled") && Global.getSettings().getBoolean("boggledDomainArchaeologyEnabled"))
        {
            int size = this.market.getSize();
            this.demand("domain_artifacts", size + 2);
        }
    }

    @Override
    public void unapply()
    {
        if(this.market.hasIndustry("BOGGLED_MESOZOIC_PARK"))
        {
            Boggled_Mesozoic_Park park = (Boggled_Mesozoic_Park) this.market.getIndustry("BOGGLED_MESOZOIC_PARK");
            park.getIncome().unmodifyMult("ind_genelab_alpha");
            park.getIncome().unmodifyMult("ind_genelab_improve");
        }

        super.unapply();
    }

    public boolean staticConditionsMet()
    {
        if(Global.getSettings().getBoolean("boggledEnableAllTerraformingProjects"))
        {
            return true;
        }
        else if(this.market.hasCondition("habitable"))
        {
            return true;
        }

        return false;
    }

    public boolean dynamicConditionsMet()
    {
        if(Global.getSettings().getBoolean("boggledEnableAllTerraformingProjects"))
        {
            return true;
        }
        else
        {
            if(!temperatureProblemsSuppressed())
            {
                return false;
            }

            if(!lightingProblemsSuppressed())
            {
                return false;
            }

            if(boggledTools.getPlanetType(this.market.getPlanetEntity()).equals("desert") && !hasWater())
            {
                return false;
            }

            return true;
        }
    }

    public boolean temperatureProblemsSuppressed()
    {
        if(this.market.hasCondition("very_hot"))
        {
            // No way to suppress Extreme Heat with only vanilla and TASC
            return false;
        }
        else if(this.market.hasCondition("hot") && !this.market.hasCondition("solar_array"))
        {
            return false;
        }
        else if(this.market.hasCondition("cold") && (!this.market.hasCondition("solar_array") && (this.market.getIndustry(Industries.POPULATION).getSpecialItem() == null || !this.market.getIndustry(Industries.POPULATION).getSpecialItem().getId().equals("orbital_fusion_lamp") || this.market.getIndustry(Industries.POPULATION).getMaxDeficit(new String[]{"volatiles"}).two > 0)))
        {
            return false;
        }
        else if(this.market.hasCondition("very_cold") && (this.market.getIndustry(Industries.POPULATION).getSpecialItem() == null || !this.market.getIndustry(Industries.POPULATION).getSpecialItem().getId().equals("orbital_fusion_lamp") || this.market.getIndustry(Industries.POPULATION).getMaxDeficit(new String[]{"volatiles"}).two > 0))
        {
            return false;
        }

        return true;
    }

    public boolean lightingProblemsSuppressed()
    {
        // Dark condition not checked because habitable and dark can't coexist in vanilla

        if(this.market.hasCondition("poor_light") && (!this.market.hasCondition("solar_array") && (this.market.getIndustry(Industries.POPULATION).getSpecialItem() == null || !this.market.getIndustry(Industries.POPULATION).getSpecialItem().getId().equals("orbital_fusion_lamp") || this.market.getIndustry(Industries.POPULATION).getMaxDeficit(new String[]{"volatiles"}).two > 0)))
        {
            return false;
        }

        return true;
    }

    public boolean hasWater()
    {
        Iterator marketsInSystem = Global.getSector().getEconomy().getMarkets(this.market.getStarSystem()).iterator();
        while(marketsInSystem.hasNext())
        {
            MarketAPI marketElement = (MarketAPI)marketsInSystem.next();
            if(marketElement.getFactionId().equals(this.market.getFactionId()) && marketElement.hasIndustry("BOGGLED_ISMARA_SLING"))
            {
                Boggled_Ismara_Sling sling = (Boggled_Ismara_Sling) marketElement.getIndustry("BOGGLED_ISMARA_SLING");
                if(sling.isFunctional() && !sling.slingHasShortage())
                {
                    return true;
                }
            }
        }

        return false;
    }

    public void doTerraforming()
    {
        if(this.terraformingProjectType.equals("Paradise transformation"))
        {
            boggledTools.terraformHabitableToParadise(this.market);
        }
        else
        {
            boggledTools.terraformBasedOnProjectType(this.market, this.terraformingProjectType);
        }
    }

    public void consumeEuteckIfNecessary()
    {
        if(this.euteck != null && Global.getSettings().getBoolean("boggledEuteckIsConsumed"))
        {
            this.euteck = null;
        }
    }

    @Override
    public boolean isAvailableToBuild()
    {
        if(!Global.getSettings().getBoolean("boggledTerraformingContentEnabled") || !Global.getSettings().getBoolean("boggledGenelabEnabled"))
        {
            return false;
        }

        //Station markets can't build
        if(this.market.getPlanetEntity() == null || this.market.getPrimaryEntity().hasTag("station"))
        {
            return false;
        }

        return true;
    }

    @Override
    public boolean showWhenUnavailable()
    {
        return false;
    }

    public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade)
    {
        this.daysWithoutShortagePollution = 0;
        this.lastDayCheckedPollution = 0;

        this.daysWithoutShortageLobsters = 0;
        this.lastDayCheckedLobsters = 0;

        this.daysWithoutShortageTerraforming = 0;
        this.lastDayCheckedTerraforming = 0;

        this.terraformingProjectType = "Paradise transformation";

        if(this.euteck != null)
        {
            this.market.getSubmarket("storage").getCargo().addSpecial(this.euteck, 1);
        }

        super.notifyBeingRemoved(mode, forUpgrade);
    }

    public float getPatherInterest()
    {
        return 10.0F;
    }

    @Override
    protected void addRightAfterDescriptionSection(TooltipMakerAPI tooltip, IndustryTooltipMode mode)
    {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        //
        // Terraforming tooltips
        //

        // tooltip.addPara("DEBUG: Required days: " + requiredDaysToCompleteTerraforming + " Accrued days: " + daysWithoutShortageTerraforming + " Project string: " + terraformingProjectType + " Shortage: " + genelabHasShortage() + " Dynamic Met: " + dynamicConditionsMet() + " Static met: " + staticConditionsMet() + " IsFunctional: " + this.isFunctional(), bad, opad);

        // Indicates whether terraforming is possible on the build screen
        if(!Global.getSettings().getBoolean("boggledEnableAllTerraformingProjects") && (mode == IndustryTooltipMode.ADD_INDUSTRY || mode == IndustryTooltipMode.QUEUED || isBuilding()))
        {
            if(!staticConditionsMet())
            {
                tooltip.addPara(this.market.getName() + " can't be terraformed using the E.U.T.E.C.K. because the surface is not human-habitable. The other functions of the Genelab will still work here.", bad, opad);
            }
        }

        // Indicates current terraforming progress
        if(this.euteck != null && staticConditionsMet() && !this.terraformingProjectType.equals("None"))
        {
            int percentTerraformingComplete = (this.daysWithoutShortageTerraforming * 100) / this.requiredDaysToCompleteTerraforming;
            if(percentTerraformingComplete > 99)
            {
                percentTerraformingComplete = 99;
            }

            tooltip.addPara("Terraforming on " + this.market.getName() + " is approximately %s complete.", opad, highlight, new String[]{percentTerraformingComplete + "%"});

            if(!dynamicConditionsMet())
            {
                if(!temperatureProblemsSuppressed())
                {
                    tooltip.addPara("Terraforming progress is currently stalled because temperatures are too extreme.", bad, opad);
                }

                if(!lightingProblemsSuppressed())
                {
                    tooltip.addPara("Terraforming progress is currently stalled because " + this.market.getName() + " is receiving insufficient sunlight.", bad, opad);
                }

                if(!hasWater() && boggledTools.getPlanetType(this.market.getPlanetEntity()).equals("desert"))
                {
                    tooltip.addPara("Terraforming progress is currently stalled due to an insufficient supply of water.", bad, opad);
                }
            }
        }
        else if (this.euteck != null && !staticConditionsMet() && !this.terraformingProjectType.equals("None"))
        {
            tooltip.addPara("Only habitable worlds can be terraformed.", bad, opad);
        }

        if(this.euteck != null && staticConditionsMet() && this.isDisrupted() && !this.terraformingProjectType.equals("None"))
        {
            tooltip.addPara("Terraforming progress is stalled while the Genelab is disrupted.", bad, opad);
        }

        //
        // Inserts pollution cleanup status
        //
        if(this.market.hasCondition("pollution") && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            //200 days to clean up; divide daysWithoutShortage by 2 to get the percent
            int percentComplete = this.daysWithoutShortagePollution / 2;

            //Makes sure the tooltip doesn't say "100% complete" on the last day due to rounding up 99.5 to 100
            if(percentComplete > 99)
            {
                percentComplete = 99;
            }

            if(this.market.hasCondition("habitable") && this.market.hasIndustry(Industries.HEAVYINDUSTRY) && this.market.getIndustry(Industries.HEAVYINDUSTRY).getSpecialItem() != null && (this.market.getIndustry(Industries.HEAVYINDUSTRY).getSpecialItem().getId().equals(Items.CORRUPTED_NANOFORGE) || this.market.getIndustry(Industries.HEAVYINDUSTRY).getSpecialItem().getId().equals(Items.PRISTINE_NANOFORGE)))
            {
                tooltip.addPara("Heavy industrial activity is currently polluting " + this.market.getName() + ". Remediation can only begin once this ceases.", bad, opad);
            }
            else
            {
                tooltip.addPara("Approximately %s of the pollution on " + this.market.getName() + " has been remediated.", opad, highlight, new String[]{percentComplete + "%"});
            }
        }

        if(this.isDisrupted() && this.market.hasCondition("pollution") && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            Pair<String, Integer> deficit = this.getMaxDeficit(new String[]{"domain_artifacts"});
            if(deficit.two != 0)
            {
                tooltip.addPara("Pollution remediation progress is stalled while the Genelab is disrupted.", bad, opad);
            }
        }

        //
        // Inserts lobster seeding status
        //
        if(this.market.hasCondition("water_surface") && !this.market.hasCondition("volturnian_lobster_pens") && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            //200 days to seed; divide daysWithoutShortage by 2 to get the percent
            int percentComplete = this.daysWithoutShortageLobsters / 2;

            //Makes sure the tooltip doesn't say "100% complete" on the last day due to rounding up 99.5 to 100
            if(percentComplete > 99)
            {
                percentComplete = 99;
            }

            tooltip.addPara("Lobster seeding is approximately %s complete.", opad, highlight, new String[]{percentComplete + "%"});

        }

        if(this.isDisrupted() && this.market.hasCondition("water_surface") && !this.market.hasCondition("volturnian_lobster_pens") && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            Pair<String, Integer> deficit = this.getMaxDeficit(new String[]{"domain_artifacts"});
            if(deficit.two != 0)
            {
                tooltip.addPara("Lobster seeding progress is stalled while the Genelab is disrupted.", bad, opad);
            }
        }
    }

    protected void addPostDemandSection(TooltipMakerAPI tooltip, boolean hasDemand, IndustryTooltipMode mode)
    {
        boolean shortage = genelabHasShortage();
        float opad = 10.0F;
        Color bad = Misc.getNegativeHighlightColor();

        if(shortage && this.market.hasCondition("pollution") && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            tooltip.addPara("Pollution remediation progress is stalled due to a shortage of Domain-era artifacts.", bad, opad);
        }

        if(shortage && this.market.hasCondition("water_surface") && !this.market.hasCondition("volturnian_lobster_pens") && mode != IndustryTooltipMode.ADD_INDUSTRY && mode != IndustryTooltipMode.QUEUED && !isBuilding())
        {
            tooltip.addPara("Lobster seeding progress is stalled due to a shortage of Domain-era artifacts.", bad, opad);
        }

        if(shortage && this.euteck != null && staticConditionsMet() && !this.terraformingProjectType.equals("None"))
        {
            tooltip.addPara("Terraforming progress is stalled due to a shortage of Domain-era artifacts.", bad, opad);
        }
    }

    public void addAlphaCoreDescription(TooltipMakerAPI tooltip, AICoreDescriptionMode mode) {
        float opad = 10.0F;
        Color highlight = Misc.getHighlightColor();
        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0F);
            text.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " + "Mesozoic Park generates %s more income.", 0.0F, highlight, (int) ((1.0F - UPKEEP_MULT) * 100.0F) + "%", "" + DEMAND_REDUCTION, "20%");
            tooltip.addImageWithText(opad);
        } else {
            tooltip.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " + "Mesozoic Park generates %s more income.", opad, highlight, (int) ((1.0F - UPKEEP_MULT) * 100.0F) + "%", "" + DEMAND_REDUCTION, "20%");
        }
    }

    public void applyAICoreToIncomeAndUpkeep()
    {
        super.applyAICoreToIncomeAndUpkeep();

        if(this.market.hasIndustry("BOGGLED_MESOZOIC_PARK"))
        {
            Boggled_Mesozoic_Park park = (Boggled_Mesozoic_Park) this.market.getIndustry("BOGGLED_MESOZOIC_PARK");
            if(this.aiCoreId != null && this.aiCoreId.equals("alpha_core") && this.isFunctional() && !this.genelabHasShortage())
            {
                park.getIncome().modifyMult("ind_genelab_alpha", IMPROVE_BONUS, "Genelab (Alpha Core)");
            }
            else
            {
                park.getIncome().unmodifyMult("ind_genelab_alpha");
            }
        }
    }

    @Override
    public boolean canImprove()
    {
        return true;
    }

    protected void applyImproveModifiers()
    {
        Boggled_Mesozoic_Park park = (Boggled_Mesozoic_Park) this.market.getIndustry("BOGGLED_MESOZOIC_PARK");
        if(park != null && this.isFunctional() && !this.genelabHasShortage())
        {
            if(this.isImproved())
            {
                park.getIncome().modifyMult("ind_genelab_improve", IMPROVE_BONUS, "Genelab (Improvements)");
            }
            else
            {
                park.getIncome().unmodifyMult("ind_genelab_improve");
            }
        }
    }

    public void addImproveDesc(TooltipMakerAPI info, ImprovementDescriptionMode mode) {
        float opad = 10f;
        Color highlight = Misc.getHighlightColor();

        if (mode == ImprovementDescriptionMode.INDUSTRY_TOOLTIP)
        {
            info.addPara("Mesozoic Park is generating %s more income.", 0f, highlight, "20%");
        }
        else
        {
            info.addPara("Mesozoic Park generates %s more income.", 0f, highlight, "20%");
        }

        info.addSpacer(opad);
        super.addImproveDesc(info, mode);
    }

    //
    // EUTECK stuff
    //

    protected boolean addNonAICoreInstalledItems(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded)
    {
        if (this.euteck == null)
        {
            return false;
        }
        else
        {
            float opad = 10.0F;
            SpecialItemSpecAPI spec = Global.getSettings().getSpecialItemSpec(this.euteck.getId());
            TooltipMakerAPI text = tooltip.beginImageWithText(spec.getIconName(), 48.0F);
            BoggledEuteckInstallableItemPlugin.EuteckEffect effect = (BoggledEuteckInstallableItemPlugin.EuteckEffect)BoggledEuteckInstallableItemPlugin.EUTECK_EFFECTS.get(this.euteck.getId());
            effect.addItemDescription(text, this.euteck, InstallableIndustryItemPlugin.InstallableItemDescriptionMode.INDUSTRY_TOOLTIP);
            tooltip.addImageWithText(opad);
            return true;
        }
    }

    public List<InstallableIndustryItemPlugin> getInstallableItems()
    {
        ArrayList<InstallableIndustryItemPlugin> list = new ArrayList();
        list.add(new BoggledEuteckInstallableItemPlugin(this));
        return list;
    }

    public List<SpecialItemData> getVisibleInstalledItems()
    {
        List<SpecialItemData> result = super.getVisibleInstalledItems();
        if (this.euteck != null)
        {
            result.add(this.euteck);
        }

        return result;
    }

    public void setEuteck(SpecialItemData euteck)
    {
        this.euteck = euteck;
    }

    public SpecialItemData getEuteck() {
        return this.euteck;
    }

    public SpecialItemData getSpecialItem() {
        return this.euteck;
    }

    public void setSpecialItem(SpecialItemData special) {
        this.euteck = special;
    }

    public boolean wantsToUseSpecialItem(SpecialItemData data)
    {
        if (this.euteck != null)
        {
            return true;
        }
        else
        {
            return this.euteck == null && data != null && BoggledEuteckInstallableItemPlugin.EUTECK_EFFECTS.containsKey(data.getId());
        }
    }
}
