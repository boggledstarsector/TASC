
package data.campaign.econ.conditions;

import com.fs.starfarer.api.campaign.econ.*;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.Map;
import data.campaign.econ.boggledTools;

public class Cramped_Quarters extends BaseHazardCondition implements MarketImmigrationModifier
{
    public Cramped_Quarters() { }

    public void advance(float amount)
    {
        super.advance(amount);
    }

    public void modifyIncoming(MarketAPI market, PopulationComposition incoming)
    {
        incoming.getWeight().modifyFlat(this.getModId(), this.getImmigrationBonus(), Misc.ucFirst(this.condition.getName().toLowerCase()));
    }

    private int getStationCrampedThreshold(MarketAPI market)
    {
        return boggledTools.getIntSetting("boggledStationCrampedQuartersSizeGrowthReductionStarts") + boggledTools.getNumberOfStationExpansions(market);
    }

    protected float getImmigrationBonus()
    {
        MarketAPI market = this.market;
        int stationCrampedThreshold = getStationCrampedThreshold(market);
        if (market.getSize() < stationCrampedThreshold)
        {
            return 0F;
        }

        float baseCrampedQuartersPenalty = (float) boggledTools.getIntSetting("boggledStationCrampedQuartersBaseGrowthPenalty");

        // Needs to return a negative value to reduce growth, so it's multiplied by -1.0F.
        // At the cramped threshold, reduces growth by 1 x the penalty.
        // The growth penalty doubles each time the market size increases by one.
        return (float) Math.pow(2.0F, market.getSize() - stationCrampedThreshold) * -1.0F * baseCrampedQuartersPenalty;
    }

    public void apply(String id)
    {
        super.apply(id);

        if(this.market == null || this.market.getTariff() == null || this.market.getFactionId() == null || this.market.getHazard() == null || this.market.getAccessibilityMod() == null)
        {
            // boggledTools.removeCondition(this.market, "cramped_quarters");
            // Don't try to remove this condition here because it will throw an exception under some unusual circumstances.
            return;
        }

        if(this.market.getTariff().getBaseValue() == 0.0f && this.market.getTariff().getModifiedValue() == 0.0f)
        {
            this.market.getTariff().modifyFlat("base_tariff_for_station", 0.30f);
        }

        if(boggledTools.getBooleanSetting("boggledStationCrampedQuartersEnabled"))
        {
            // Market growth modifier
            this.market.addTransientImmigrationModifier(this);
        }

        if(boggledTools.getIntSetting("boggledStationHazardRatingModifier") != 0)
        {
            // Market hazard modifier
            float hazard = (float)boggledTools.getIntSetting("boggledStationHazardRatingModifier") / 100.0F;
            this.market.getHazard().modifyFlat(id, hazard, "Base station hazard");
        }

        if(boggledTools.getIntSetting("boggledStationAccessibilityBoost") != 0)
        {
            // Accessibility boost
            float access = (float)boggledTools.getIntSetting("boggledStationAccessibilityBoost") / 100.0F;
            this.market.getAccessibilityMod().modifyFlat(this.getModId(), access, "Space station");
        }
    }

    public void unapply(String id)
    {
        super.unapply(id);

        if(this.market == null || this.market.getTariff() == null || this.market.getFactionId() == null || this.market.getHazard() == null || this.market.getAccessibilityMod() == null)
        {
            // boggledTools.removeCondition(this.market, "cramped_quarters");
            // Don't try to remove this condition here because it will throw an exception under some unusual circumstances.
            return;
        }

        this.market.getTariff().unmodifyFlat("base_tariff_for_station");

        if(boggledTools.getBooleanSetting("boggledStationCrampedQuartersEnabled"))
        {
            this.market.removeTransientImmigrationModifier(this);
        }

        if(boggledTools.getIntSetting("boggledStationHazardRatingModifier") != 0)
        {
            this.market.getHazard().unmodifyFlat(id);
        }

        if(boggledTools.getIntSetting("boggledStationAccessibilityBoost") != 0)
        {
            this.market.getAccessibilityMod().unmodifyFlat("Space station");
        }
    }

    public Map<String, String> getTokenReplacements() { return super.getTokenReplacements(); }

    public boolean showIcon()
    {
        if(boggledTools.getBooleanSetting("boggledStationCrampedQuartersEnabled"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded)
    {
        super.createTooltipAfterDescription(tooltip, expanded);

        tooltip.addPara("Population growth reduction at this station begins at market size %s and gets worse if the station continues to grow further beyond that limit.", 10.0F, Misc.getHighlightColor(), new String[]{getStationCrampedThreshold(this.market) + ""});

        if(boggledTools.getBooleanSetting("boggledStationCrampedQuartersPlayerCanPayToIncreaseStationSize"))
        {
            tooltip.addPara("Stations can be expanded to increase the maximum number of residents. Number of times this station has been expanded: %s", 10.0F, Misc.getHighlightColor(), new String[]{boggledTools.getNumberOfStationExpansions(this.market) + ""});
        }

        if(boggledTools.getBooleanSetting("boggledStationCrampedQuartersPlayerCanPayToIncreaseStationSize") && boggledTools.getBooleanSetting("boggledStationProgressiveIncreaseInCostsToExpandStation"))
        {
            tooltip.addPara("Station expansions become more progressively more expensive as the size of the station grows. Each new expansion is twice the cost of the previous one.", 10.0F, Misc.getHighlightColor(), new String[]{boggledTools.getNumberOfStationExpansions(this.market) + ""});
        }
    }
}
