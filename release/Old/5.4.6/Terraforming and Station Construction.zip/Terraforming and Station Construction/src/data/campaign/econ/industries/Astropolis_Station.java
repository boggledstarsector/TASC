package data.campaign.econ.industries;

import java.awt.Color;
import java.util.Iterator;
import java.util.Random;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.submarkets.StoragePlugin;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.CoreCampaignPluginImpl;
import com.fs.starfarer.api.impl.campaign.CoreScript;
import com.fs.starfarer.api.impl.campaign.events.CoreEventProbabilityManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposableLuddicPathFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.DisposablePirateFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.EconomyFleetRouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.MercFleetManagerV2;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.campaign.*;
import com.fs.starfarer.combat.entities.terrain.Planet;
import data.campaign.econ.BoggledStationConstructionIDs;
import data.campaign.econ.boggledTools;

public class Astropolis_Station extends BaseIndustry
{
    @Override
    public void apply() {
        super.apply(true);
    }

    @Override
    public void unapply() {
        super.unapply();
    }

    @Override
    public void finishBuildingOrUpgrading() {
        super.finishBuildingOrUpgrading();
    }

    @Override
    protected void buildingFinished()
    {
        super.buildingFinished();

        if(!this.market.getFaction().equals(Global.getSector().getPlayerFaction()) && !this.market.isPlayerOwned())
        {
            this.market.removeIndustry("ASTROPOLIS_STATION",null,false);
            return;
        }

        int numAstro = numAstroInOrbit();
        StarSystemAPI system = this.market.getStarSystem();
        float orbitRadius = this.market.getPrimaryEntity().getRadius() + 375.0F;

        FactionAPI playerFaction = Global.getSector().getPlayerFaction();
        String playerFactionID = playerFaction.getId();

        if(numAstro == 0)
        {
            SectorEntityToken newAstropolis = system.addCustomEntity("boggled_astropolisAlpha", this.market.getPrimaryEntity().getName() + " Astropolis Alpha", "boggled_astropolis_station_alpha_small", playerFactionID);
            newAstropolis.setCircularOrbitPointingDown(this.market.getPrimaryEntity(), boggledTools.randomOrbitalAngleFloat(), orbitRadius, orbitRadius / 10.0F);
            newAstropolis.setInteractionImage("illustrations", "orbital_construction");

            SectorEntityToken newAstropolisLights = system.addCustomEntity("boggled_astropolisAlphaLights", this.market.getPrimaryEntity().getName() + " Astropolis Alpha Lights Overlay", "boggled_astropolis_station_alpha_small_lights_overlay", playerFactionID);
            newAstropolisLights.setOrbit(newAstropolis.getOrbit().makeCopy());

            //Create the astropolis market
            MarketAPI market = Global.getFactory().createMarket(this.market.getPrimaryEntity().getName() + "astropolisAlphaMarket", newAstropolis.getName(), 3);
            market.setSize(3);

            market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
            market.setPrimaryEntity(newAstropolis);

            market.setFactionId(playerFactionID);
            if(this.market.isPlayerOwned())
            {
                market.setPlayerOwned(true);
            }

            market.addCondition(Conditions.POPULATION_3);
            market.addCondition("sprite_controller");
            market.addCondition("cramped_quarters");

            market.addIndustry(Industries.POPULATION);
            market.addIndustry(Industries.SPACEPORT);

            newAstropolis.setMarket(market);

            Global.getSector().getEconomy().addMarket(market, true);

            //If the player doesn't view the colony management screen within a few days of market creation, then there can be a bug related to population growth
            if(this.market.isPlayerOwned())
            {
                Global.getSector().getCampaignUI().showInteractionDialog(newAstropolis);
            }

            market.addSubmarket("storage");
            StoragePlugin storage = (StoragePlugin)market.getSubmarket("storage").getPlugin();
            if(this.market.isPlayerOwned())
            {
                storage.setPlayerPaidToUnlock(true);
            }
            else
            {
                storage.setPlayerPaidToUnlock(false);
            }
            market.addSubmarket("local_resources");
        }
        else if(numAstro == 1)
        {
            Iterator allEntitiesInSystem = this.market.getStarSystem().getAllEntities().iterator();
            SectorEntityToken alphaAstroToken = null;

            while(allEntitiesInSystem.hasNext())
            {
                SectorEntityToken entity = (SectorEntityToken)allEntitiesInSystem.next();
                if (entity.getOrbitFocus() != null && entity.getOrbitFocus().equals(this.market.getPrimaryEntity()) && entity.getMarket() != null && !this.market.equals(entity.getMarket()) && entity.getCustomEntityType() != null && !entity.getCustomEntityType().contains("lights_overlay") && !entity.getCustomEntityType().contains("boggled_siphon_station"))
                {
                    alphaAstroToken = entity;
                    break;
                }
            }

            SectorEntityToken newAstropolis = system.addCustomEntity("boggled_astropolisBeta", this.market.getPrimaryEntity().getName() + " Astropolis Beta", "boggled_astropolis_station_beta_small", playerFactionID);
            newAstropolis.setCircularOrbitPointingDown(this.market.getPrimaryEntity(), alphaAstroToken.getCircularOrbitAngle() + 120f, orbitRadius, orbitRadius / 10.0F);
            newAstropolis.setInteractionImage("illustrations", "orbital_construction");

            SectorEntityToken newAstropolisLights = system.addCustomEntity("boggled_astropolisBetaLights", this.market.getPrimaryEntity().getName() + " Astropolis Beta Lights Overlay", "boggled_astropolis_station_beta_small_lights_overlay", playerFactionID);
            newAstropolisLights.setOrbit(newAstropolis.getOrbit().makeCopy());

            //Create the astropolis market
            MarketAPI market = Global.getFactory().createMarket(this.market.getPrimaryEntity().getName() + "astropolisBetaMarket", newAstropolis.getName(), 3);
            market.setSize(3);
            market.setFactionId(playerFactionID);

            market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
            market.setPrimaryEntity(newAstropolis);

            market.setFactionId(playerFactionID);
            if(this.market.isPlayerOwned())
            {
                market.setPlayerOwned(true);
            }

            market.addCondition(Conditions.POPULATION_3);
            market.addCondition("sprite_controller");
            market.addCondition("cramped_quarters");

            market.addIndustry(Industries.POPULATION);
            market.addIndustry(Industries.SPACEPORT);

            newAstropolis.setMarket(market);

            Global.getSector().getEconomy().addMarket(market, true);

            //If the player doesn't view the colony management screen within a few days of market creation, then there can be a bug related to population growth
            if(this.market.isPlayerOwned())
            {
                Global.getSector().getCampaignUI().showInteractionDialog(newAstropolis);
            }

            market.addSubmarket("storage");
            StoragePlugin storage = (StoragePlugin)market.getSubmarket("storage").getPlugin();
            if(this.market.isPlayerOwned())
            {
                storage.setPlayerPaidToUnlock(true);
            }
            else
            {
                storage.setPlayerPaidToUnlock(false);
            }
            market.addSubmarket("local_resources");
        }
        else if(numAstro == 2)
        {
            Iterator allEntitiesInSystem = this.market.getStarSystem().getAllEntities().iterator();
            SectorEntityToken alphaAstroToken = null;

            while(allEntitiesInSystem.hasNext())
            {
                SectorEntityToken entity = (SectorEntityToken)allEntitiesInSystem.next();
                if (entity.getOrbitFocus() != null && entity.getOrbitFocus().equals(this.market.getPrimaryEntity()) && entity.getCustomEntityType() != null && entity.hasTag("boggled_astropolis") && entity.getCustomEntityType().contains("boggled_astropolis_station_beta"))
                {
                    alphaAstroToken = entity;
                    break;
                }
            }

            SectorEntityToken newAstropolis = system.addCustomEntity("boggled_astropolisGamma", this.market.getPrimaryEntity().getName() + " Astropolis Gamma", "boggled_astropolis_station_gamma_small", playerFactionID);
            newAstropolis.setCircularOrbitPointingDown(this.market.getPrimaryEntity(), alphaAstroToken.getCircularOrbitAngle() + 120f, orbitRadius, orbitRadius / 10.0F);
            newAstropolis.setInteractionImage("illustrations", "orbital_construction");

            SectorEntityToken newAstropolisLights = system.addCustomEntity("boggled_astropolisGammaLights", this.market.getPrimaryEntity().getName() + " Astropolis Gamma Lights Overlay", "boggled_astropolis_station_gamma_small_lights_overlay", playerFactionID);
            newAstropolisLights.setOrbit(newAstropolis.getOrbit().makeCopy());

            //Create the astropolis market
            MarketAPI market = Global.getFactory().createMarket(this.market.getPrimaryEntity().getName() + "astropolisGammaMarket", newAstropolis.getName(), 3);
            market.setSize(3);
            market.setFactionId(playerFactionID);

            market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
            market.setPrimaryEntity(newAstropolis);

            market.setFactionId(playerFactionID);
            if(this.market.isPlayerOwned())
            {
                market.setPlayerOwned(true);
            }

            market.addCondition(Conditions.POPULATION_3);
            market.addCondition("sprite_controller");
            market.addCondition("cramped_quarters");

            market.addIndustry(Industries.POPULATION);
            market.addIndustry(Industries.SPACEPORT);

            newAstropolis.setMarket(market);

            Global.getSector().getEconomy().addMarket(market, true);

            //If the player doesn't view the colony management screen within a few days of market creation, then there can be a bug related to population growth
            if(this.market.isPlayerOwned())
            {
                Global.getSector().getCampaignUI().showInteractionDialog(newAstropolis);
            }

            market.addSubmarket("storage");
            StoragePlugin storage = (StoragePlugin)market.getSubmarket("storage").getPlugin();
            if(this.market.isPlayerOwned())
            {
                storage.setPlayerPaidToUnlock(true);
            }
            else
            {
                storage.setPlayerPaidToUnlock(false);
            }
            market.addSubmarket("local_resources");
        }

        this.market.removeIndustry("ASTROPOLIS_STATION",null,false);
    }

    @Override
    public void startBuilding() {
        super.startBuilding();
    }

    final class astropolisOrbitBlocker
    {
        public SectorEntityToken blocker;
        public String reason;

        public astropolisOrbitBlocker(SectorEntityToken blocker, String reason)
        {
            this.blocker = blocker;
            this.reason = reason;
        }
    }

    private astropolisOrbitBlocker astropolisOrbitBlocked()
    {
        SectorEntityToken hostToken = this.market.getPrimaryEntity();

        //check if the host market radius is too small
        if(hostToken.getRadius() < 125f)
        {
            return new astropolisOrbitBlocker(null, "radius_too_small");
        }

        //check if the host market is too close to its orbital focus
        if(hostToken.getOrbitFocus() != null && hostToken.getCircularOrbitRadius() < (hostToken.getOrbitFocus().getRadius() + 900f))
        {
            return new astropolisOrbitBlocker(hostToken.getOrbitFocus(), "too_close_to_focus");
        }

        //check if the host market is too close to a star
        if(hostToken.getOrbitFocus() != null && hostToken.getOrbitFocus().isStar() && hostToken.getCircularOrbitRadius() < (hostToken.getOrbitFocus().getRadius() + 1400f))
        {
            return new astropolisOrbitBlocker(hostToken.getOrbitFocus(), "too_close_to_star");
        }

        //check if the host market has a moon that is too close to it
        Iterator allPlanetsInSystem = this.market.getStarSystem().getPlanets().iterator();
        while(allPlanetsInSystem.hasNext())
        {
            PlanetAPI planet = (PlanetAPI) allPlanetsInSystem.next();
            if (planet.getOrbitFocus() != null && !planet.isStar() && planet.getOrbitFocus().equals(hostToken) && planet.getCircularOrbitRadius() < (hostToken.getRadius() + 500f) && planet.getRadius() != 0)
            {
                return new astropolisOrbitBlocker(planet, "moon_too_close");
            }
        }
        allPlanetsInSystem = null;

        //check if the host market and other planets are orbiting the same focus are too close to each other
        allPlanetsInSystem = this.market.getStarSystem().getPlanets().iterator();
        while(allPlanetsInSystem.hasNext())
        {
            PlanetAPI planet = (PlanetAPI)allPlanetsInSystem.next();
            if (planet.getOrbitFocus() != null && !planet.isStar() && planet.getOrbitFocus().equals(hostToken.getOrbitFocus()))
            {
                if(Math.abs(planet.getCircularOrbitRadius() - hostToken.getCircularOrbitRadius()) < 400f && Math.abs(planet.getCircularOrbitRadius() - hostToken.getCircularOrbitRadius()) != 0)
                {
                    return new astropolisOrbitBlocker(planet, "same_focus_too_close");
                }
            }
        }

        return null;
    }

    private int numAstroInOrbit()
    {
        int numAstropoli = 0;
        if(this.market.getStarSystem() == null)
        {
            return numAstropoli;
        }
        Iterator allEntitiesInSystem = this.market.getStarSystem().getAllEntities().iterator();

        while(allEntitiesInSystem.hasNext())
        {
            SectorEntityToken entity = (SectorEntityToken)allEntitiesInSystem.next();
            if (entity.getOrbitFocus() != null && entity.getOrbitFocus().equals(this.market.getPrimaryEntity()) && entity.getMarket() != null && !entity.getMarket().equals(this.market) && entity.getCustomEntityType() != null && !entity.getCustomEntityType().contains("lights_overlay") && !entity.getCustomEntityType().contains("boggled_siphon_station"))
            {
                numAstropoli++;
            }
        }

        return numAstropoli;
    }

    @Override
    public boolean isAvailableToBuild()
    {
        //Checks for governorship by player. Governed planets have isPlayerOwned() equals true but
        //the controlling FactionAPI is still major faction, not player
        if(this.market.isPlayerOwned() && !this.market.getFaction().equals(Global.getSector().getPlayerFaction()) && !Global.getSettings().getBoolean("boggledCanBuildAstropolisOnPurchasedGovernorshipPlanets"))
        {
            return false;
        }

        if(!(Global.getSettings().getBoolean("boggledAstropolisEnabled") && Global.getSettings().getBoolean("boggledStationConstructionContentEnabled")))
        {
            return false;
        }

        int maxAstropoliPerPlanet = Global.getSettings().getInt("boggledMaxNumAstropoliPerPlanet");
        if(maxAstropoliPerPlanet > 3 || maxAstropoliPerPlanet < 1)
        {
            return false;
        }

        if(this.market.isPlayerOwned() && !this.market.getPrimaryEntity().hasTag("station") && this.market.getStarSystem() != null && numAstroInOrbit() < maxAstropoliPerPlanet && astropolisOrbitBlocked() == null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public boolean showWhenUnavailable()
    {
        if(this.market.isPlayerOwned() && !this.market.getFaction().equals(Global.getSector().getPlayerFaction()) && !Global.getSettings().getBoolean("boggledCanBuildAstropolisOnPurchasedGovernorshipPlanets"))
        {
            return true;
        }

        if(!Global.getSettings().getBoolean("boggledAstropolisEnabled"))
        {
            return false;
        }

        if(this.market.getPrimaryEntity().hasTag("station"))
        {
            return false;
        }

        return true;
    }

    @Override
    public String getUnavailableReason()
    {
        String worldName = this.market.getName();

        if(this.market.isPlayerOwned() && !this.market.getFaction().equals(Global.getSector().getPlayerFaction()) && !Global.getSettings().getBoolean("boggledCanBuildAstropolisOnPurchasedGovernorshipPlanets"))
        {
            return "Other factions won't permit you to build an astropolis in orbit around planets they own.";
        }

        int maxAstropoliPerPlanet = Global.getSettings().getInt("boggledMaxNumAstropoliPerPlanet");
        if(maxAstropoliPerPlanet > 3)
        {
            return "Permissible values for boggledMaxNumAstropoliPerPlanet are 0, 1, 2 or 3. Please use the settings file for this mod to enter a permissible value.";
        }
        else if(numAstroInOrbit() >= maxAstropoliPerPlanet && maxAstropoliPerPlanet == 0)
        {
            return "Astropolis construction has been disabled using the settings file of this mod. To enable construction, set boggledMaxNumAstropoliPerPlanet to 1, 2 or 3.";
        }
        else if(numAstroInOrbit() >= maxAstropoliPerPlanet && maxAstropoliPerPlanet == 1)
        {
            return "Each world can only support a single astropolis. " + worldName + " already has an astropolis in orbit.";
        }
        else if(numAstroInOrbit() >= maxAstropoliPerPlanet && maxAstropoliPerPlanet > 1)
        {
            return "Each world can support a maximum of " + maxAstropoliPerPlanet + " astropoli. " + worldName + " has reached or exceeded that limit.";
        }

        astropolisOrbitBlocker astroblocker = astropolisOrbitBlocked();
        if(astroblocker != null && astroblocker.reason != null && astroblocker.reason.equals("radius_too_small"))
        {
            return "This world is too small to host an astropolis.";
        }
        else if(astroblocker != null && astroblocker.reason != null && astroblocker.reason.equals("too_close_to_focus"))
        {
            return "An astropolis would be unable to achieve a satisfactory orbit around this world because it is orbiting too close to " + astroblocker.blocker.getName() + ".";
        }
        else if(astroblocker != null && astroblocker.reason != null && astroblocker.reason.equals("too_close_to_star"))
        {
            return "This world is too close to " + astroblocker.blocker.getName() + " to host an astropolis.";
        }
        else if(astroblocker != null && astroblocker.reason != null && astroblocker.reason.equals("moon_too_close"))
        {
            return "An astropolis would be unable to achieve a satisfactory orbit around this world because " + astroblocker.blocker.getName() + " is orbiting too close to it.";
        }
        else if(astroblocker != null && astroblocker.reason != null && astroblocker.reason.equals("same_focus_too_close"))
        {
            return "An astropolis would be unable to achieve a satisfactory orbit here because " + astroblocker.blocker.getName() + " periodically approaches very near to this world. The astropolis would lack sufficient propulsion systems to maintain a steady orbit when the gravity of " + astroblocker.blocker.getName() + " disrupts it.";
        }

        return "Error in getUnavailableReason(). Please tell Boggled about this in the forum thread for this mod.";
    }

    //These should remove the ability to install an AI core
    @Override
    public void addAICoreSection(TooltipMakerAPI tooltip, AICoreDescriptionMode mode)
    {
        //this.addAICoreSection(tooltip, this.aiCoreId, mode);
    }

    @Override
    public void addAICoreSection(TooltipMakerAPI tooltip, String coreId, AICoreDescriptionMode mode)
    {
        /*
        float opad = 10.0F;
        FactionAPI faction = this.market.getFaction();
        Color color = faction.getBaseUIColor();
        Color dark = faction.getDarkUIColor();
        if (mode == AICoreDescriptionMode.MANAGE_CORE_TOOLTIP && coreId == null) {
            tooltip.addPara("No AI core currently assigned. Click to assign an AI core from your cargo.", opad);
        } else {
            boolean alpha = coreId.equals("alpha_core");
            boolean beta = coreId.equals("beta_core");
            boolean gamma = coreId.equals("gamma_core");
            if (alpha) {
                this.addAlphaCoreDescription(tooltip, mode);
            } else if (beta) {
                this.addBetaCoreDescription(tooltip, mode);
            } else if (gamma) {
                this.addGammaCoreDescription(tooltip, mode);
            }

        }
         */
    }

    @Override
    public void addInstalledItemsSection(IndustryTooltipMode mode, TooltipMakerAPI tooltip, boolean expanded)
    {
        /*
        float opad = 10.0F;
        FactionAPI faction = this.market.getFaction();
        Color color = faction.getBaseUIColor();
        Color dark = faction.getDarkUIColor();
        LabelAPI heading = tooltip.addSectionHeading("Items", color, dark, Alignment.MID, opad);
        boolean addedSomething = false;
        if (this.aiCoreId != null) {
            AICoreDescriptionMode aiCoreDescMode = AICoreDescriptionMode.INDUSTRY_TOOLTIP;
            this.addAICoreSection(tooltip, this.aiCoreId, aiCoreDescMode);
            addedSomething = true;
        }

        addedSomething |= this.addNonAICoreInstalledItems(mode, tooltip, expanded);
        if (!addedSomething) {
            heading.setText("No items installed");
        }
         */
    }
}
