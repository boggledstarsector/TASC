package data.scripts;

import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.util.Misc;
import data.campaign.econ.boggledTools;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.lang.String;

public class boggledCraftingPrintRequirements extends BaseCommandPlugin
{
    protected SectorEntityToken entity;

    public boggledCraftingPrintRequirements() {}

    public boggledCraftingPrintRequirements(SectorEntityToken entity) {
        this.init(entity);
    }

    protected void init(SectorEntityToken entity)
    {
        this.entity = entity;
    }

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap)
    {
        if(dialog == null) return false;

        this.entity = dialog.getInteractionTarget();
        TextPanelAPI text = dialog.getTextPanel();

        if(this.entity.getMarket() == null)
        {
            return true;
        }
        else
        {
            Color highlight = Misc.getHighlightColor();
            Color good = Misc.getPositiveHighlightColor();
            Color bad = Misc.getNegativeHighlightColor();

            MarketAPI market = this.entity.getMarket();

            // Print crafting requirements
            text.addPara("Requirements to Craft Domain-Tech Items:", highlight, new String[]{""});
            String[] requirements = boggledTools.getProjectRequirementsStrings("boggledCrafting");
            int i;
            for (i = 0; i < requirements.length; i++)
            {
                if(boggledTools.requirementMet(market, requirements[i]))
                {
                    text.addPara("      - %s", good, new String[]{requirements[i] + ""});
                }
                else
                {
                    text.addPara("      - %s", bad, new String[]{requirements[i] + ""});
                }
            }
        }

        return true;
    }
}